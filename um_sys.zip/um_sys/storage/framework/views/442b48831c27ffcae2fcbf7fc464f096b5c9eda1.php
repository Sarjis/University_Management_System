<section class="content">
    <div class="container">
        <div class="row">

            <div class="col-md-10 ">
                <router-view></router-view>
            </div>
            <!--/.col (right) -->
        </div>
        <!-- /.row -->
    </div><!-- /.container-fluid -->
</section><?php /**PATH H:\Xampp\htdocs\Git Project\my_projects\ums\resources\views/admin/includes/router-view.blade.php ENDPATH**/ ?>