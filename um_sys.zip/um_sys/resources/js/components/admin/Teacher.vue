<template>
    
</template>

<script>
    export default {
        name: "Teacher"
    }
</script>

<style scoped>

</style>