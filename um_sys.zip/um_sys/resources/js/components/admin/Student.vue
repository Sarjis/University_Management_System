<template>
    
</template>

<script>
    export default {
        name: "Student"
    }
</script>

<style scoped>

</style>