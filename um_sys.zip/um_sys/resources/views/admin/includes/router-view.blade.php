<section class="content">
    <div class="container">
        <div class="row">

            <div class="col-md-10 ">
                <router-view></router-view>
            </div>
            <!--/.col (right) -->
        </div>
        <!-- /.row -->
    </div><!-- /.container-fluid -->
</section>